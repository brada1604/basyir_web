<?= $this->extend('layout/v_template') ?>

<?= $this->section('content') ?>

SELAMAT DATANG

<?= $this->endSection() ?>