        <tr align="center">
			<td colspan="5">
				SELAMAT DATANG <?= $session->get('name');?> - <?= $session->get('nip');?>
			</td>
		</tr>